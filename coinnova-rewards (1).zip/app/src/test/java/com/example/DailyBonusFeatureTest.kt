package com.example

import com.example.data.model.UserProfile
import com.example.data.repository.CoinNovaRepository
import com.example.data.repository.DailyBonusResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DailyBonusFeatureTest {

    private val cooldownMs = CoinNovaRepository.DAILY_BONUS_COOLDOWN_MS

    @Test
    fun dailyBonus_isEligible_whenNeverClaimed() {
        val user = UserProfile(lastDailyBonusTimestamp = 0L)
        val now = System.currentTimeMillis()
        val elapsed = now - user.lastDailyBonusTimestamp
        val isEligible = user.lastDailyBonusTimestamp == 0L || elapsed >= cooldownMs

        assertTrue("Bonus should be eligible when never claimed before", isEligible)
    }

    @Test
    fun dailyBonus_isNotEligible_within24Hours() {
        val now = 1700000000000L
        val claimedRecently = now - (2 * 60 * 60 * 1000L) // Claimed 2 hours ago
        val user = UserProfile(lastDailyBonusTimestamp = claimedRecently)

        val elapsed = now - user.lastDailyBonusTimestamp
        val isEligible = user.lastDailyBonusTimestamp == 0L || elapsed >= cooldownMs
        val remainingMillis = cooldownMs - elapsed

        assertFalse("Bonus should not be claimable after only 2 hours", isEligible)
        assertEquals(22 * 60 * 60 * 1000L, remainingMillis)
    }

    @Test
    fun dailyBonus_becomesEligible_afterExactly24Hours() {
        val now = 1700000000000L
        val claimedExactly24HoursAgo = now - cooldownMs
        val user = UserProfile(lastDailyBonusTimestamp = claimedExactly24HoursAgo)

        val elapsed = now - user.lastDailyBonusTimestamp
        val isEligible = user.lastDailyBonusTimestamp == 0L || elapsed >= cooldownMs

        assertTrue("Bonus should become claimable after 24 hours have elapsed", isEligible)
    }

    @Test
    fun dailyBonus_becomesEligible_afterMoreThan24Hours() {
        val now = 1700000000000L
        val claimed30HoursAgo = now - (30 * 60 * 60 * 1000L)
        val user = UserProfile(lastDailyBonusTimestamp = claimed30HoursAgo)

        val elapsed = now - user.lastDailyBonusTimestamp
        val isEligible = user.lastDailyBonusTimestamp == 0L || elapsed >= cooldownMs

        assertTrue("Bonus should be claimable after 30 hours", isEligible)
    }

    @Test
    fun dailyBonus_cooldownCalculation_returnsZero_whenExpired() {
        val now = 1700000000000L
        val claimed25HoursAgo = now - (25 * 60 * 60 * 1000L)
        val elapsed = now - claimed25HoursAgo
        val remaining = (cooldownMs - elapsed).coerceAtLeast(0L)

        assertEquals(0L, remaining)
    }
}
