package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.CoinNovaBlue
import com.example.ui.theme.CoinNovaPurple
import com.example.ui.theme.CoinNovaSurface
import com.example.ui.theme.TextMuted
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

object AdManager {
    private const val TAG = "AdManager"
    const val APP_ID = "ca-app-pub-9193871716375125~6076523954"
    const val REWARDED_AD_ID = "ca-app-pub-9193871716375125/6639183628"
    const val BANNER_AD_ID = "ca-app-pub-9193871716375125/6134207582"

    private var rewardedAd: RewardedAd? = null
    private var isLoadingRewarded = false

    fun init(context: Context) {
        MobileAds.initialize(context) { status ->
            Log.d(TAG, "AdMob initialized: $status")
            preloadRewardedAd(context)
        }
    }

    fun initialize(context: Context) = init(context)

    fun preloadRewardedAd(context: Context) {
        if (isLoadingRewarded || rewardedAd != null) return
        isLoadingRewarded = true
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            REWARDED_AD_ID,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.w(TAG, "RewardedAd failed to load: ${loadAdError.message}")
                    rewardedAd = null
                    isLoadingRewarded = false
                }

                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d(TAG, "RewardedAd loaded successfully")
                    rewardedAd = ad
                    isLoadingRewarded = false
                }
            }
        )
    }

    fun showRewardedAd(
        activity: Activity,
        onRewardEarned: (Int) -> Unit,
        onAdClosed: () -> Unit,
        onFallbackSimulation: () -> Unit
    ) {
        val ad = rewardedAd
        if (ad != null) {
            ad.show(activity) { rewardItem ->
                Log.d(TAG, "User earned reward: ${rewardItem.amount}")
                onRewardEarned(rewardItem.amount)
            }
            rewardedAd = null
            preloadRewardedAd(activity)
            onAdClosed()
        } else {
            // Fallback simulation when ad is not yet loaded / offline / emulator
            Log.d(TAG, "Rewarded ad not cached, using interactive video ad experience")
            preloadRewardedAd(activity)
            onFallbackSimulation()
        }
    }
}

@Composable
fun AdMobBanner(
    modifier: Modifier = Modifier,
    adUnitId: String = AdManager.BANNER_AD_ID
) {
    val context = LocalContext.current
    val adView = remember {
        AdView(context).apply {
            setAdSize(AdSize.BANNER)
            this.adUnitId = adUnitId
            adListener = object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w("AdMobBanner", "Banner ad failed to load: ${error.message}")
                }
            }
            loadAd(AdRequest.Builder().build())
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CoinNovaSurface)
            .border(
                1.dp,
                Brush.horizontalGradient(listOf(CoinNovaBlue.copy(alpha = 0.3f), CoinNovaPurple.copy(alpha = 0.3f))),
                RoundedCornerShape(14.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            modifier = Modifier.fillMaxWidth(),
            factory = { adView }
        )

        // Fallback luxury placeholder behind the adview in case network delays or no fill
        Text(
            text = "CoinNova Sponsored Ads • Secure & Verified",
            color = TextMuted.copy(alpha = 0.4f),
            fontSize = 10.sp,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
    }
}
