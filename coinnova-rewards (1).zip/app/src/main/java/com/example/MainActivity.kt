package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ads.AdManager
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.LuckySpinScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.QuizScreen
import com.example.ui.screens.RedeemHistoryScreen
import com.example.ui.screens.RedeemScreen
import com.example.ui.screens.ReferScreen
import com.example.ui.screens.ScratchCardScreen
import com.example.ui.screens.SpinHistoryScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.WatchAdScreen
import com.example.ui.theme.CoinNovaTheme
import com.example.ui.viewmodel.CoinNovaViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: CoinNovaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize AdMob & Preload Rewarded Ads
        AdManager.initialize(this)

        setContent {
            CoinNovaTheme {
                val navController = rememberNavController()
                CoinNovaNavGraph(
                    navController = navController,
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
fun CoinNovaNavGraph(
    navController: NavHostController,
    viewModel: CoinNovaViewModel,
    modifier: Modifier = Modifier
) {
    val userProfile by viewModel.userProfile.collectAsState()
    val spinsLeft by viewModel.spinsLeftToday.collectAsState()
    val redeemList by viewModel.redeemRecords.collectAsState()
    val spinList by viewModel.spinRecords.collectAsState()
    val isDailyBonusAvailable by viewModel.isDailyBonusAvailable.collectAsState()
    val dailyBonusCooldownFormatted by viewModel.dailyBonusCooldownFormatted.collectAsState()
    val lastDailyBonusFormatted by viewModel.lastDailyBonusFormatted.collectAsState()

    NavHost(
        navController = navController,
        startDestination = "splash",
        modifier = modifier.fillMaxSize()
    ) {
        // Splash Screen (2 seconds animated loading bar + floating coins)
        composable("splash") {
            SplashScreen(
                isLoggedIn = userProfile?.isLoggedIn == true,
                onFinish = { destination ->
                    navController.navigate(destination) {
                        popUpTo("splash") { inclusive = true }
                    }
                }
            )
        }

        // Login Screen (Google Sign-In selector + popup + redirect to Home)
        composable("login") {
            LoginScreen(
                onLoginSuccess = { name, email ->
                    viewModel.login(name, email)
                    navController.navigate("home") {
                        popUpTo("login") { inclusive = true }
                    }
                }
            )
        }

        // Home Screen (Hero Card, Feature Grid, Bottom Nav, AdMob Banner)
        composable("home") {
            HomeScreen(
                userProfile = userProfile,
                isDailyBonusAvailable = isDailyBonusAvailable,
                dailyBonusCooldownFormatted = dailyBonusCooldownFormatted,
                lastDailyBonusFormatted = lastDailyBonusFormatted,
                onNavigate = { route ->
                    if (route == "home") return@HomeScreen
                    navController.navigate(route) {
                        launchSingleTop = true
                    }
                },
                onClaimDailyBonus = { callback ->
                    viewModel.claimDailyBonus(callback)
                }
            )
        }

        // Watch Ad Screen (60s video countdown + +5 Coins)
        composable("watch_ad") {
            WatchAdScreen(
                onBack = { navController.popBackStack() },
                onRewardEarned = { onFinish ->
                    viewModel.watchAdComplete(onFinish)
                }
            )
        }

        // Quiz Screen (4 options + +10 Coins + Red shake animation)
        composable("quiz") {
            QuizScreen(
                currentCoins = userProfile?.coins ?: 0,
                onBack = { navController.popBackStack() },
                onCorrectAnswer = { onFinish ->
                    viewModel.quizAnswerCorrect(onFinish)
                }
            )
        }

        // Lucky Spin Screen (8 segments, 10 spins daily limit, realistic physics)
        composable("lucky_spin") {
            LuckySpinScreen(
                currentCoins = userProfile?.coins ?: 0,
                spinsLeft = spinsLeft,
                onBack = { navController.popBackStack() },
                onSpinComplete = { wonCoins, callback ->
                    viewModel.performSpin(wonCoins, callback)
                },
                onViewSpinHistory = {
                    navController.navigate("spin_history")
                }
            )
        }

        // Scratch Card Screen (Canvas finger scratch + Rewarded Ad claim)
        composable("scratch_card") {
            ScratchCardScreen(
                currentCoins = userProfile?.coins ?: 0,
                onBack = { navController.popBackStack() },
                onClaimCoins = { wonCoins, callback ->
                    viewModel.scratchCardComplete(wonCoins, callback)
                }
            )
        }

        // Redeem Screen (Google Play, Amazon, Flipkart, Free Fire + Banner Ad)
        composable("redeem") {
            RedeemScreen(
                currentCoins = userProfile?.coins ?: 0,
                onBack = { navController.popBackStack() },
                onViewHistory = { navController.navigate("redeem_history") },
                onRedeem = { brand, title, cost, value, recipient, callback ->
                    viewModel.redeemReward(brand, title, cost, value, recipient, callback)
                }
            )
        }

        // Refer Screen (Code, Copy, Share, Link generator, Invite bonus)
        composable("refer") {
            ReferScreen(
                userProfile = userProfile,
                onNavigate = { route ->
                    if (route == "refer") return@ReferScreen
                    navController.navigate(route) {
                        launchSingleTop = true
                    }
                },
                onApplyCode = { code, callback ->
                    viewModel.applyReferralCode(code, callback)
                }
            )
        }

        // Leaderboard Screen (Top 100 users, Podium, Highlight current user)
        composable("leaderboard") {
            LeaderboardScreen(
                userProfile = userProfile,
                onNavigate = { route ->
                    if (route == "leaderboard") return@LeaderboardScreen
                    navController.navigate(route) {
                        launchSingleTop = true
                    }
                }
            )
        }

        // Profile Screen (Photo, Name, Level, Balance, History, Settings, Logout)
        composable("profile") {
            ProfileScreen(
                userProfile = userProfile,
                onNavigate = { route ->
                    if (route == "profile") return@ProfileScreen
                    navController.navigate(route) {
                        launchSingleTop = true
                    }
                },
                onLogout = {
                    viewModel.logout()
                    navController.navigate("login") {
                        popUpTo("home") { inclusive = true }
                    }
                }
            )
        }

        // Redeem History (Pending=Orange, Approved=Green, Rejected=Red)
        composable("redeem_history") {
            RedeemHistoryScreen(
                redeemList = redeemList,
                onBack = { navController.popBackStack() }
            )
        }

        // Spin History
        composable("spin_history") {
            SpinHistoryScreen(
                spinList = spinList,
                onBack = { navController.popBackStack() }
            )
        }
    }
}

