package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val name: String = "Alex Morgan",
    val email: String = "alex.morgan@gmail.com",
    val avatarUrl: String = "",
    val coins: Int = 250,
    val level: Int = 3,
    val spinsLeft: Int = 10,
    val lastSpinDate: String = "",
    val lastDailyBonusDate: String = "",
    val lastDailyBonusTimestamp: Long = 0L,
    val referralCode: String = "NOVA-7829X",
    val isLoggedIn: Boolean = false
)

@Entity(tableName = "redeem_records")
data class RedeemRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val brand: String,
    val rewardTitle: String,
    val coinsCost: Int,
    val cashValue: String,
    val recipientDetails: String,
    val status: String, // "Pending", "Approved", "Rejected"
    val codeOrVoucher: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "spin_records")
data class SpinRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val coinsWon: Int,
    val timestamp: Long = System.currentTimeMillis()
)
