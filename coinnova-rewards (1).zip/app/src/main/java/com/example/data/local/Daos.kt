package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.RedeemRecord
import com.example.data.model.SpinRecord
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getUserProfile(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    suspend fun getUserProfileOnce(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(user: UserProfile)

    @Update
    suspend fun update(user: UserProfile)

    @Query("UPDATE user_profile SET coins = coins + :amount WHERE id = 1")
    suspend fun addCoins(amount: Int)

    @Query("UPDATE user_profile SET coins = coins - :amount WHERE id = 1")
    suspend fun deductCoins(amount: Int)

    @Query("UPDATE user_profile SET spinsLeft = :count, lastSpinDate = :date WHERE id = 1")
    suspend fun updateSpins(count: Int, date: String)
}

@Dao
interface RedeemDao {
    @Query("SELECT * FROM redeem_records ORDER BY timestamp DESC")
    fun getAllRedeemRecords(): Flow<List<RedeemRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: RedeemRecord): Long
}

@Dao
interface SpinDao {
    @Query("SELECT * FROM spin_records ORDER BY timestamp DESC")
    fun getAllSpinRecords(): Flow<List<SpinRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: SpinRecord): Long
}
