package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.RedeemRecord
import com.example.data.model.SpinRecord
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface DailyBonusResult {
    data class Success(val coinsClaimed: Int, val claimedTimestamp: Long) : DailyBonusResult
    data class CooldownActive(val remainingMillis: Long, val nextAvailableTimestamp: Long) : DailyBonusResult
    data class Error(val message: String) : DailyBonusResult
}

class CoinNovaRepository(private val database: AppDatabase) {
    private val userDao = database.userDao()
    private val redeemDao = database.redeemDao()
    private val spinDao = database.spinDao()

    val userProfile: Flow<UserProfile?> = userDao.getUserProfile()
    val redeemHistory: Flow<List<RedeemRecord>> = redeemDao.getAllRedeemRecords()
    val spinHistory: Flow<List<SpinRecord>> = spinDao.getAllSpinRecords()

    private fun getCurrentDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    suspend fun ensureInitialData() {
        val existingUser = userDao.getUserProfileOnce()
        val today = getCurrentDateString()
        if (existingUser == null) {
            val newUser = UserProfile(
                id = 1,
                name = "Alex Morgan",
                email = "alex.morgan@gmail.com",
                coins = 380,
                level = 3,
                spinsLeft = 10,
                lastSpinDate = today,
                lastDailyBonusDate = "",
                referralCode = "NOVA-7829X",
                isLoggedIn = false
            )
            userDao.insertOrUpdate(newUser)

            // Seed sample redeem records to showcase status colors: Pending (Orange), Approved (Green), Rejected (Red)
            redeemDao.insert(
                RedeemRecord(
                    brand = "Google Play",
                    rewardTitle = "₹10 Google Play Code",
                    coinsCost = 100,
                    cashValue = "₹10",
                    recipientDetails = "alex.morgan@gmail.com",
                    status = "Approved",
                    timestamp = System.currentTimeMillis() - 86400000L * 2
                )
            )
            redeemDao.insert(
                RedeemRecord(
                    brand = "Amazon",
                    rewardTitle = "₹50 Amazon Gift Card",
                    coinsCost = 500,
                    cashValue = "₹50",
                    recipientDetails = "alex.morgan@gmail.com",
                    status = "Pending",
                    timestamp = System.currentTimeMillis() - 3600000L * 5
                )
            )
            redeemDao.insert(
                RedeemRecord(
                    brand = "Free Fire",
                    rewardTitle = "50 Free Fire Diamonds",
                    coinsCost = 100,
                    cashValue = "50 Diamonds",
                    recipientDetails = "UID: 94827103",
                    status = "Rejected",
                    timestamp = System.currentTimeMillis() - 86400000L * 5
                )
            )

            // Seed sample spin records
            spinDao.insert(SpinRecord(coinsWon = 50, timestamp = System.currentTimeMillis() - 86400000L))
            spinDao.insert(SpinRecord(coinsWon = 30, timestamp = System.currentTimeMillis() - 7200000L))
        } else {
            // Check if spin reset is needed for a new day
            if (existingUser.lastSpinDate != today) {
                userDao.updateSpins(10, today)
            }
        }
    }

    suspend fun setLoginState(isLoggedIn: Boolean, name: String = "Alex Morgan", email: String = "alex.morgan@gmail.com") {
        val user = userDao.getUserProfileOnce() ?: UserProfile()
        userDao.insertOrUpdate(
            user.copy(
                isLoggedIn = isLoggedIn,
                name = name,
                email = email
            )
        )
    }

    suspend fun addCoins(amount: Int) {
        userDao.addCoins(amount)
    }

    suspend fun claimDailyBonus(currentTimeMillis: Long = System.currentTimeMillis()): DailyBonusResult {
        val user = userDao.getUserProfileOnce() ?: return DailyBonusResult.Error("User profile not found")
        val lastClaim = user.lastDailyBonusTimestamp
        val elapsed = currentTimeMillis - lastClaim

        // Check if 24 hours have passed since last claim
        if (lastClaim > 0L && elapsed < DAILY_BONUS_COOLDOWN_MS) {
            val remaining = DAILY_BONUS_COOLDOWN_MS - elapsed
            return DailyBonusResult.CooldownActive(
                remainingMillis = remaining,
                nextAvailableTimestamp = lastClaim + DAILY_BONUS_COOLDOWN_MS
            )
        }

        val today = getCurrentDateString()
        userDao.insertOrUpdate(
            user.copy(
                coins = user.coins + DAILY_BONUS_COINS,
                lastDailyBonusDate = today,
                lastDailyBonusTimestamp = currentTimeMillis
            )
        )
        return DailyBonusResult.Success(
            coinsClaimed = DAILY_BONUS_COINS,
            claimedTimestamp = currentTimeMillis
        )
    }

    fun isDailyBonusEligible(lastClaimTimestamp: Long, currentTimeMillis: Long = System.currentTimeMillis()): Boolean {
        if (lastClaimTimestamp <= 0L) return true
        return (currentTimeMillis - lastClaimTimestamp) >= DAILY_BONUS_COOLDOWN_MS
    }

    fun getRemainingBonusCooldownMillis(lastClaimTimestamp: Long, currentTimeMillis: Long = System.currentTimeMillis()): Long {
        if (lastClaimTimestamp <= 0L) return 0L
        val elapsed = currentTimeMillis - lastClaimTimestamp
        return (DAILY_BONUS_COOLDOWN_MS - elapsed).coerceAtLeast(0L)
    }

    companion object {
        const val DAILY_BONUS_COOLDOWN_MS = 24 * 60 * 60 * 1000L // 24 hours in milliseconds (86,400,000 ms)
        const val DAILY_BONUS_COINS = 25
    }

    suspend fun executeSpin(coinsWon: Int): Boolean {
        val user = userDao.getUserProfileOnce() ?: return false
        val today = getCurrentDateString()
        val currentSpins = if (user.lastSpinDate == today) user.spinsLeft else 10
        if (currentSpins <= 0) return false

        val updatedSpins = currentSpins - 1
        userDao.insertOrUpdate(
            user.copy(
                coins = user.coins + coinsWon,
                spinsLeft = updatedSpins,
                lastSpinDate = today
            )
        )
        spinDao.insert(SpinRecord(coinsWon = coinsWon, timestamp = System.currentTimeMillis()))
        return true
    }

    suspend fun redeemReward(
        brand: String,
        rewardTitle: String,
        coinsCost: Int,
        cashValue: String,
        recipientDetails: String
    ): Boolean {
        val user = userDao.getUserProfileOnce() ?: return false
        if (user.coins < coinsCost) return false

        userDao.deductCoins(coinsCost)
        redeemDao.insert(
            RedeemRecord(
                brand = brand,
                rewardTitle = rewardTitle,
                coinsCost = coinsCost,
                cashValue = cashValue,
                recipientDetails = recipientDetails,
                status = "Pending",
                timestamp = System.currentTimeMillis()
            )
        )
        return true
    }
}
