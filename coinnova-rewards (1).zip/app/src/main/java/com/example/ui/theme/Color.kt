package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CoinNova Theme Palette
val CoinNovaBg = Color(0xFF07152D)
val CoinNovaSurface = Color(0xFF0D2247)
val CoinNovaSurfaceCard = Color(0xFF132A54)
val CoinNovaSurfaceCardAlpha = Color(0xCC0D2247)
val CoinNovaSurfaceLight = Color(0xFF1B386D)
val CoinNovaBlue = Color(0xFF2F7BFF)
val CoinNovaPurple = Color(0xFF7A3CFF)
val CoinNovaGold = Color(0xFFFFC83D)
val CoinNovaGoldDark = Color(0xFFE5A812)
val CoinNovaGreen = Color(0xFF20C76F)
val CoinNovaRed = Color(0xFFFF4D4D)
val CoinNovaOrange = Color(0xFFFF9500)

val TextWhite = Color(0xFFFFFFFF)
val TextLightGray = Color(0xFFBAC7DE)
val TextMuted = Color(0xFF7B91B8)
val GlassBorder = Color(0x332F7BFF)
val GlassBorderGold = Color(0x44FFC83D)
val GlassBorderPurple = Color(0x447A3CFF)
