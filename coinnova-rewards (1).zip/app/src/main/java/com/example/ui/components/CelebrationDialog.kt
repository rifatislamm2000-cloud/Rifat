package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.CoinNovaBlue
import com.example.ui.theme.CoinNovaGold
import com.example.ui.theme.CoinNovaGreen
import com.example.ui.theme.CoinNovaPurple
import com.example.ui.theme.CoinNovaSurface
import com.example.ui.theme.CoinNovaSurfaceCard
import com.example.ui.theme.GlassBorderGold
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextWhite
import kotlin.random.Random

@Composable
fun RewardCelebrationDialog(
    coinsWon: Int,
    title: String = "Congratulations!",
    subtitle: String = "You earned",
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            CoinNovaSurfaceCard,
                            CoinNovaSurface
                        )
                    )
                )
                .border(1.5.dp, GlassBorderGold, RoundedCornerShape(22.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            // Confetti canvas
            ConfettiEffect(modifier = Modifier.matchParentSize())

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "🎉 $title",
                    color = CoinNovaGold,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = subtitle,
                    color = TextLightGray,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Big Golden Coin Icon
                GlowingCoinIcon(size = 80.dp)

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "+$coinsWon Coins",
                    color = CoinNovaGold,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Added to your CoinNova balance",
                    color = TextLightGray,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CoinNovaBlue
                    )
                ) {
                    Text(
                        text = "Claim to Wallet",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
fun ConfettiEffect(modifier: Modifier = Modifier) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 2000, easing = LinearEasing)
        )
    }

    val colors = listOf(CoinNovaGold, CoinNovaBlue, CoinNovaPurple, CoinNovaGreen, Color.White)
    val particles = remember {
        List(40) {
            val randomAngle = Random.nextFloat() * 360f
            val randomSpeed = Random.nextFloat() * 200f + 100f
            val randomColor = colors.random()
            val randomSize = Random.nextFloat() * 8f + 4f
            Particle(randomAngle, randomSpeed, randomColor, randomSize)
        }
    }

    Canvas(modifier = modifier) {
        val center = Offset(size.width / 2f, size.height * 0.45f)
        particles.forEach { p ->
            val rad = Math.toRadians(p.angle.toDouble())
            val dist = p.speed * progress.value
            val x = (center.x + dist * Math.cos(rad)).toFloat()
            val y = (center.y + dist * Math.sin(rad) + (progress.value * 80f)).toFloat()
            drawCircle(
                color = p.color.copy(alpha = 1f - (progress.value * 0.5f)),
                radius = p.size,
                center = Offset(x, y)
            )
        }
    }
}

private data class Particle(
    val angle: Float,
    val speed: Float,
    val color: Color,
    val size: Float
)
