package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ads.AdMobBanner
import com.example.data.model.UserProfile
import com.example.ui.components.CoinNovaBottomNav
import com.example.ui.components.CoinNovaTopBar
import com.example.ui.components.GlassCard
import com.example.ui.components.GlowingCoinIcon
import com.example.ui.components.RewardCelebrationDialog
import com.example.ui.theme.CoinNovaBg
import com.example.ui.theme.CoinNovaBlue
import com.example.ui.theme.CoinNovaGold
import com.example.ui.theme.CoinNovaGreen
import com.example.ui.theme.CoinNovaPurple
import com.example.ui.theme.CoinNovaSurface
import com.example.ui.theme.CoinNovaSurfaceCard
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassBorderGold
import com.example.ui.theme.GlassBorderPurple
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    userProfile: UserProfile?,
    onNavigate: (String) -> Unit,
    onClaimDailyBonus: ((Boolean, String) -> Unit) -> Unit,
    isDailyBonusAvailable: Boolean = true,
    dailyBonusCooldownFormatted: String = "Available Now",
    lastDailyBonusFormatted: String = "Never claimed",
    modifier: Modifier = Modifier
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showNotificationDialog by remember { mutableStateOf(false) }
    var celebrationCoinsWon by remember { mutableStateOf<Int?>(null) }

    val isBonusClaimed = !isDailyBonusAvailable

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CoinNovaBg,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CoinNovaTopBar(
                username = userProfile?.name ?: "Alex Morgan",
                coinBalance = userProfile?.coins ?: 0,
                level = userProfile?.level ?: 3,
                onAvatarClick = { onNavigate("profile") },
                onNotificationClick = { showNotificationDialog = true },
                onCoinClick = { onNavigate("redeem") }
            )
        },
        bottomBar = {
            Column {
                // Banner Ad on Home bottom (as mandated by prompt)
                AdMobBanner(
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                )
                CoinNovaBottomNav(
                    currentRoute = "home",
                    onNavigate = onNavigate
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp)
        ) {
            // Hero Card: "Welcome to CoinNova" & "Daily Bonus Gift"
            item {
                HeroCard(
                    isClaimedToday = isBonusClaimed,
                    cooldownFormatted = dailyBonusCooldownFormatted,
                    lastClaimedFormatted = lastDailyBonusFormatted,
                    onClaim = {
                        onClaimDailyBonus { success, message ->
                            scope.launch {
                                if (success) {
                                    celebrationCoinsWon = 25
                                } else {
                                    snackbarHostState.showSnackbar(message)
                                }
                            }
                        }
                    }
                )
            }

            // Quick Redeem Banner Card
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = GlassBorderPurple,
                    gradientColors = listOf(
                        Color(0xFF1D1B48),
                        CoinNovaSurfaceCard
                    ),
                    onClick = { onNavigate("redeem") }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(CoinNovaPurple.copy(alpha = 0.3f))
                                    .border(1.dp, CoinNovaPurple, RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CurrencyExchange,
                                    contentDescription = "Redeem",
                                    tint = CoinNovaGold,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "Redeem Gift Cards",
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "Google Play, Amazon, Free Fire",
                                    color = TextLightGray,
                                    fontSize = 12.sp
                                )
                            }
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(22.dp))
                                .background(CoinNovaBlue)
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Redeem",
                                color = TextWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Section Header: "Earn More Coins"
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Earn Coins",
                        color = TextWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "60 FPS Instant Rewards",
                        color = CoinNovaGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Feature Grid (2x2):
            // 1. Watch Ad (+5 Coins)
            // 2. Quiz (+10 Coins)
            // 3. Lucky Spin
            // 4. Scratch Card
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        FeatureCard(
                            modifier = Modifier.weight(1f),
                            title = "Watch Ad",
                            reward = "+5 Coins",
                            icon = Icons.Default.OndemandVideo,
                            badgeColor = CoinNovaBlue,
                            glowColor = CoinNovaBlue.copy(alpha = 0.25f),
                            onClick = { onNavigate("watch_ad") }
                        )
                        FeatureCard(
                            modifier = Modifier.weight(1f),
                            title = "Quiz",
                            reward = "+10 Coins",
                            icon = Icons.Default.HelpOutline,
                            badgeColor = CoinNovaPurple,
                            glowColor = CoinNovaPurple.copy(alpha = 0.25f),
                            onClick = { onNavigate("quiz") }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        FeatureCard(
                            modifier = Modifier.weight(1f),
                            title = "Lucky Spin",
                            reward = "Up to 1000 Coins",
                            icon = Icons.Default.RotateRight,
                            badgeColor = CoinNovaGold,
                            glowColor = CoinNovaGold.copy(alpha = 0.25f),
                            onClick = { onNavigate("lucky_spin") }
                        )
                        FeatureCard(
                            modifier = Modifier.weight(1f),
                            title = "Scratch Card",
                            reward = "2–5 Coins (Unlimited)",
                            icon = Icons.Default.ConfirmationNumber,
                            badgeColor = CoinNovaGreen,
                            glowColor = CoinNovaGreen.copy(alpha = 0.25f),
                            onClick = { onNavigate("scratch_card") }
                        )
                    }
                }
            }
        }
    }

    // Daily bonus celebration dialog
    celebrationCoinsWon?.let { coins ->
        RewardCelebrationDialog(
            coinsWon = coins,
            title = "Daily Bonus Claimed!",
            subtitle = "You collected your daily gift",
            onDismiss = { celebrationCoinsWon = null }
        )
    }

    // Notification Dialog
    if (showNotificationDialog) {
        NotificationCenterDialog(onDismiss = { showNotificationDialog = false })
    }
}

/**
 * Hero Card: "Welcome to CoinNova" and "Daily Bonus Gift"
 */
@Composable
fun HeroCard(
    isClaimedToday: Boolean,
    cooldownFormatted: String = "Available Now",
    lastClaimedFormatted: String = "Never claimed",
    onClaim: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier.fillMaxWidth(),
        cornerRadius = 22.dp,
        borderColor = GlassBorderGold,
        gradientColors = listOf(
            Color(0xFF142C5B),
            Color(0xFF0F1E3D)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = CoinNovaGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Welcome to CoinNova",
                            color = CoinNovaGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Daily Bonus Gift",
                        color = TextWhite,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Claim your +25 gold coins bonus every 24 hours to keep your streak alive!",
                        color = TextLightGray,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                GlowingCoinIcon(size = 52.dp)
            }

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = onClaim,
                enabled = !isClaimedToday,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(22.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isClaimedToday) CoinNovaSurface else CoinNovaGold,
                    contentColor = if (isClaimedToday) TextMuted else Color(0xFF161616),
                    disabledContainerColor = Color(0xFF16243E),
                    disabledContentColor = TextMuted
                )
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isClaimedToday) Icons.Default.Schedule else Icons.Default.CardGiftcard,
                        contentDescription = null,
                        tint = if (isClaimedToday) TextMuted else Color(0xFF161616),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isClaimedToday) "Next Bonus in: $cooldownFormatted" else "Claim +25 Coins Gift",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            if (isClaimedToday) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = CoinNovaGreen,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Last claimed: $lastClaimedFormatted • 24h cooldown",
                        color = TextLightGray.copy(alpha = 0.7f),
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

/**
 * Feature Grid item card with rounded 22px corners, luxury border, and glowing icon
 */
@Composable
fun FeatureCard(
    title: String,
    reward: String,
    icon: ImageVector,
    badgeColor: Color,
    glowColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier
            .height(138.dp),
        cornerRadius = 22.dp,
        borderColor = badgeColor.copy(alpha = 0.35f),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(glowColor)
                        .border(1.dp, badgeColor.copy(alpha = 0.6f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = badgeColor,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CoinNovaSurface)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "PLAY",
                        color = CoinNovaGold,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            Column {
                Text(
                    text = title,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = reward,
                    color = badgeColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

/**
 * Interactive Notification Dialog
 */
@Composable
fun NotificationCenterDialog(onDismiss: () -> Unit) {
    val notifications = listOf(
        Pair("Daily Spin Available", "Your 10 daily spins are ready! Spin to win up to 1000 coins."),
        Pair("New Quiz Added", "Answer quick questions and win +10 coins instantly."),
        Pair("Google Play Card in Stock", "Redeem ₹10 Google Play code for just 100 coins!")
    )

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(CoinNovaSurface)
                .border(1.dp, GlassBorder, RoundedCornerShape(22.dp))
                .padding(20.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Notifications",
                        color = TextWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextLightGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                notifications.forEach { (title, desc) ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = title,
                            color = CoinNovaGold,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = desc,
                            color = TextLightGray,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(0.5.dp)
                                .background(GlassBorder)
                        )
                    }
                }
            }
        }
    }
}
