package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.RedeemRecord
import com.example.data.model.SpinRecord
import com.example.data.model.UserProfile
import com.example.data.repository.CoinNovaRepository
import com.example.data.repository.DailyBonusResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CoinNovaViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getInstance(application)
    private val repository = CoinNovaRepository(database)

    val userProfile: StateFlow<UserProfile?> = repository.userProfile
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val redeemRecords: StateFlow<List<RedeemRecord>> = repository.redeemHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val spinRecords: StateFlow<List<SpinRecord>> = repository.spinHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val redeemHistory: StateFlow<List<RedeemRecord>> get() = redeemRecords
    val spinHistory: StateFlow<List<SpinRecord>> get() = spinRecords

    val spinsLeftToday: StateFlow<Int> = repository.userProfile
        .map { it?.spinsLeft ?: 10 }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 10
        )

    private val _loginSuccessEvent = MutableStateFlow(false)
    val loginSuccessEvent: StateFlow<Boolean> = _loginSuccessEvent.asStateFlow()

    companion object {
        const val DAILY_BONUS_COOLDOWN_MS = 24 * 60 * 60 * 1000L // 24 hours (86,400,000 ms)
        const val DAILY_BONUS_COINS = 25
    }

    // Tracks the last timestamp (ms) when user claimed their daily bonus
    val lastDailyBonusTimestamp: StateFlow<Long> = repository.userProfile
        .map { it?.lastDailyBonusTimestamp ?: 0L }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0L
        )

    // Formatted date and time of the last daily bonus claim
    val lastDailyBonusFormatted: StateFlow<String> = lastDailyBonusTimestamp
        .map { formatBonusTimestamp(it) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = "Never claimed"
        )

    // Remaining cooldown milliseconds until 24 hours pass (0 if available)
    private val _dailyBonusCooldownRemainingMillis = MutableStateFlow(0L)
    val dailyBonusCooldownRemainingMillis: StateFlow<Long> = _dailyBonusCooldownRemainingMillis.asStateFlow()

    // Boolean indicating if the 24-hour bonus can be claimed right now
    private val _isDailyBonusAvailable = MutableStateFlow(true)
    val isDailyBonusAvailable: StateFlow<Boolean> = _isDailyBonusAvailable.asStateFlow()

    // Formatted countdown timer string (e.g., "Available Now" or "18h 42m 10s")
    private val _dailyBonusCooldownFormatted = MutableStateFlow("Available Now")
    val dailyBonusCooldownFormatted: StateFlow<String> = _dailyBonusCooldownFormatted.asStateFlow()

    // Exact timestamp when the next bonus will be available
    val dailyBonusNextAvailableTimeMillis: StateFlow<Long> = lastDailyBonusTimestamp
        .map { last -> if (last > 0L) last + DAILY_BONUS_COOLDOWN_MS else 0L }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0L
        )

    private val _notificationMessage = MutableStateFlow<String?>(null)
    val notificationMessage: StateFlow<String?> = _notificationMessage.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureInitialData()
        }
        startDailyBonusTimer()
    }

    private fun startDailyBonusTimer() {
        viewModelScope.launch {
            // Periodically refresh the 24-hour cooldown countdown and availability
            while (true) {
                val now = System.currentTimeMillis()
                val lastClaim = lastDailyBonusTimestamp.value
                val elapsed = now - lastClaim

                if (lastClaim <= 0L || elapsed >= DAILY_BONUS_COOLDOWN_MS) {
                    _dailyBonusCooldownRemainingMillis.value = 0L
                    _isDailyBonusAvailable.value = true
                    _dailyBonusCooldownFormatted.value = "Available Now"
                } else {
                    val remaining = DAILY_BONUS_COOLDOWN_MS - elapsed
                    _dailyBonusCooldownRemainingMillis.value = remaining
                    _isDailyBonusAvailable.value = false
                    _dailyBonusCooldownFormatted.value = formatDuration(remaining)
                }
                delay(1000L)
            }
        }
    }

    fun canClaimDailyBonus(): Boolean {
        val lastClaim = lastDailyBonusTimestamp.value
        if (lastClaim <= 0L) return true
        return (System.currentTimeMillis() - lastClaim) >= DAILY_BONUS_COOLDOWN_MS
    }

    fun getTimeRemainingUntilNextBonus(): Long {
        val lastClaim = lastDailyBonusTimestamp.value
        if (lastClaim <= 0L) return 0L
        val elapsed = System.currentTimeMillis() - lastClaim
        return (DAILY_BONUS_COOLDOWN_MS - elapsed).coerceAtLeast(0L)
    }

    fun getFormattedTimeRemaining(): String {
        val remaining = getTimeRemainingUntilNextBonus()
        return if (remaining <= 0L) "Available Now" else formatDuration(remaining)
    }

    fun getLastDailyBonusTimeFormatted(): String {
        return formatBonusTimestamp(lastDailyBonusTimestamp.value)
    }

    fun login(name: String, email: String) {
        loginWithGoogle(name, email)
    }

    fun loginWithGoogle(name: String = "Alex Morgan", email: String = "alex.morgan@gmail.com") {
        viewModelScope.launch {
            repository.setLoginState(isLoggedIn = true, name = name, email = email)
            _loginSuccessEvent.value = true
        }
    }

    fun clearLoginSuccessEvent() {
        _loginSuccessEvent.value = false
    }

    fun logout(onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.setLoginState(isLoggedIn = false)
            onComplete()
        }
    }

    fun claimDailyBonus(onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val result = repository.claimDailyBonus(now)
            when (result) {
                is DailyBonusResult.Success -> {
                    // Update immediate state
                    _isDailyBonusAvailable.value = false
                    _dailyBonusCooldownRemainingMillis.value = DAILY_BONUS_COOLDOWN_MS
                    _dailyBonusCooldownFormatted.value = formatDuration(DAILY_BONUS_COOLDOWN_MS)
                    val successMsg = "🎉 You claimed +${result.coinsClaimed} Daily Bonus Coins!"
                    _notificationMessage.value = successMsg
                    onResult(true, successMsg)
                }
                is DailyBonusResult.CooldownActive -> {
                    val formatted = formatDuration(result.remainingMillis)
                    val cooldownMsg = "Daily bonus cooldown active! Next claim available in $formatted."
                    _notificationMessage.value = cooldownMsg
                    onResult(false, cooldownMsg)
                }
                is DailyBonusResult.Error -> {
                    onResult(false, result.message)
                }
            }
        }
    }

    private fun formatDuration(millis: Long): String {
        if (millis <= 0L) return "Available Now"
        val totalSeconds = (millis + 999) / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return when {
            hours > 0 -> String.format(Locale.getDefault(), "%02dh %02dm %02ds", hours, minutes, seconds)
            minutes > 0 -> String.format(Locale.getDefault(), "%02dm %02ds", minutes, seconds)
            else -> String.format(Locale.getDefault(), "%ds", seconds)
        }
    }

    private fun formatBonusTimestamp(timestamp: Long): String {
        if (timestamp <= 0L) return "Never claimed"
        val sdf = SimpleDateFormat("MMM d, yyyy, hh:mm a", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun watchAdComplete(onSuccess: () -> Unit) {
        onWatchAdCompleted(onSuccess)
    }

    fun onWatchAdCompleted(onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.addCoins(5)
            onSuccess()
        }
    }

    fun quizAnswerCorrect(onSuccess: () -> Unit) {
        onQuizCorrectAnswer(onSuccess)
    }

    fun onQuizCorrectAnswer(onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.addCoins(10)
            onSuccess()
        }
    }

    fun performSpin(coinsWon: Int, onResult: (Boolean) -> Unit) {
        executeSpin(coinsWon, onResult)
    }

    fun executeSpin(coinsWon: Int, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = repository.executeSpin(coinsWon)
            onResult(success)
        }
    }

    fun scratchCardComplete(coins: Int, onComplete: () -> Unit) {
        claimScratchReward(coins, onComplete)
    }

    fun claimScratchReward(coins: Int, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.addCoins(coins)
            onSuccess()
        }
    }

    fun redeemReward(
        brand: String,
        rewardTitle: String,
        coinsCost: Int,
        cashValue: String,
        recipientDetails: String,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val currentCoins = userProfile.value?.coins ?: 0
            if (currentCoins < coinsCost) {
                onResult(false, "Insufficient coins! You need $coinsCost coins.")
                return@launch
            }
            if (recipientDetails.isBlank()) {
                onResult(false, "Please enter recipient details (Email / ID).")
                return@launch
            }

            val success = repository.redeemReward(
                brand = brand,
                rewardTitle = rewardTitle,
                coinsCost = coinsCost,
                cashValue = cashValue,
                recipientDetails = recipientDetails
            )
            if (success) {
                onResult(true, "Redeem request submitted successfully! Status: Pending.")
            } else {
                onResult(false, "Redeem failed. Please try again.")
            }
        }
    }

    fun applyReferralCode(code: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val trimmed = code.trim().uppercase()
            val user = userProfile.value
            if (trimmed.isEmpty()) {
                onResult(false, "Please enter a referral code.")
                return@launch
            }
            if (trimmed == user?.referralCode) {
                onResult(false, "You cannot enter your own referral code!")
                return@launch
            }
            repository.addCoins(25)
            onResult(true, "Referral code applied! You earned +25 Coins.")
        }
    }
}
