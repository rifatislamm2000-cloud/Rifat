package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalMall
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ads.AdMobBanner
import com.example.ui.components.CoinBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.GlowingCoinIcon
import com.example.ui.theme.CoinNovaBg
import com.example.ui.theme.CoinNovaBlue
import com.example.ui.theme.CoinNovaGold
import com.example.ui.theme.CoinNovaGreen
import com.example.ui.theme.CoinNovaPurple
import com.example.ui.theme.CoinNovaSurface
import com.example.ui.theme.CoinNovaSurfaceCard
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassBorderGold
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch

data class RedeemItem(
    val brand: String,
    val rewardTitle: String,
    val coinRequirement: Int,
    val cashValue: String,
    val brandIcon: ImageVector,
    val iconBgColor: Color
)

val googlePlayRewards = listOf(
    RedeemItem("Google Play", "₹10 Google Play Code", 100, "₹10", Icons.Default.PlayArrow, Color(0xFF0086F8)),
    RedeemItem("Google Play", "₹50 Google Play Code", 500, "₹50", Icons.Default.PlayArrow, Color(0xFF0086F8)),
    RedeemItem("Google Play", "₹100 Google Play Code", 1000, "₹100", Icons.Default.PlayArrow, Color(0xFF0086F8)),
    RedeemItem("Google Play", "₹500 Google Play Code", 5000, "₹500", Icons.Default.PlayArrow, Color(0xFF0086F8)),
    RedeemItem("Google Play", "₹1000 Google Play Code", 10000, "₹1000", Icons.Default.PlayArrow, Color(0xFF0086F8)),
    RedeemItem("Google Play", "₹2000 Google Play Code", 20000, "₹2000", Icons.Default.PlayArrow, Color(0xFF0086F8))
)

val amazonRewards = listOf(
    RedeemItem("Amazon", "₹25 Amazon Gift Card", 250, "₹25", Icons.Default.ShoppingCart, Color(0xFFFF9900)),
    RedeemItem("Amazon", "₹50 Amazon Gift Card", 500, "₹50", Icons.Default.ShoppingCart, Color(0xFFFF9900)),
    RedeemItem("Amazon", "₹100 Amazon Gift Card", 1000, "₹100", Icons.Default.ShoppingCart, Color(0xFFFF9900)),
    RedeemItem("Amazon", "₹500 Amazon Gift Card", 5000, "₹500", Icons.Default.ShoppingCart, Color(0xFFFF9900)),
    RedeemItem("Amazon", "₹1000 Amazon Gift Card", 10000, "₹1000", Icons.Default.ShoppingCart, Color(0xFFFF9900))
)

val flipkartRewards = listOf(
    RedeemItem("Flipkart", "₹50 Flipkart Voucher", 500, "₹50", Icons.Default.LocalMall, Color(0xFF2874F0)),
    RedeemItem("Flipkart", "₹100 Flipkart Voucher", 1000, "₹100", Icons.Default.LocalMall, Color(0xFF2874F0)),
    RedeemItem("Flipkart", "₹500 Flipkart Voucher", 5000, "₹500", Icons.Default.LocalMall, Color(0xFF2874F0)),
    RedeemItem("Flipkart", "₹1000 Flipkart Voucher", 10000, "₹1000", Icons.Default.LocalMall, Color(0xFF2874F0))
)

val freeFireRewards = listOf(
    RedeemItem("Free Fire", "50 Free Fire Diamonds", 100, "50 Diamonds", Icons.Default.SportsEsports, Color(0xFFFF3366)),
    RedeemItem("Free Fire", "250 Free Fire Diamonds", 500, "250 Diamonds", Icons.Default.SportsEsports, Color(0xFFFF3366)),
    RedeemItem("Free Fire", "520 Free Fire Diamonds", 1000, "520 Diamonds", Icons.Default.SportsEsports, Color(0xFFFF3366)),
    RedeemItem("Free Fire", "1060 Free Fire Diamonds", 2000, "1060 Diamonds", Icons.Default.SportsEsports, Color(0xFFFF3366))
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RedeemScreen(
    currentCoins: Int,
    onBack: () -> Unit,
    onViewHistory: () -> Unit,
    onRedeem: (String, String, Int, String, String, (Boolean, String) -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    val categories = listOf("Google Play", "Amazon", "Flipkart", "Free Fire")
    var selectedCategory by remember { mutableStateOf("Google Play") }
    var itemToRedeem by remember { mutableStateOf<RedeemItem?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val currentList = when (selectedCategory) {
        "Google Play" -> googlePlayRewards
        "Amazon" -> amazonRewards
        "Flipkart" -> flipkartRewards
        else -> freeFireRewards
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CoinNovaBg,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Redeem Rewards",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextWhite
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onViewHistory) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "History",
                            tint = CoinNovaGold
                        )
                    }
                    CoinBadge(coins = currentCoins, modifier = Modifier.padding(end = 12.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CoinNovaSurface)
            )
        },
        bottomBar = {
            // Banner Ad on Redeem bottom (as mandated by prompt)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CoinNovaBg)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                AdMobBanner()
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp)
        ) {
            // Category Selector Tabs
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp)
                ) {
                    items(categories) { cat ->
                        val isSelected = selectedCategory == cat
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(22.dp))
                                .background(
                                    if (isSelected) CoinNovaBlue else CoinNovaSurface
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) CoinNovaBlue else GlassBorder,
                                    RoundedCornerShape(22.dp)
                                )
                                .clickable { selectedCategory = cat }
                                .padding(horizontal = 18.dp, vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = cat,
                                color = if (isSelected) TextWhite else TextLightGray,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }

            // Category summary header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "$selectedCategory Rewards",
                        color = TextWhite,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Instant voucher codes",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            }

            // Redeem Cards List
            items(currentList) { item ->
                val canAfford = currentCoins >= item.coinRequirement
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 22.dp,
                    borderColor = if (canAfford) GlassBorderGold else GlassBorder,
                    gradientColors = listOf(
                        CoinNovaSurfaceCard,
                        CoinNovaSurface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Brand Icon + Info
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(item.iconBgColor.copy(alpha = 0.2f))
                                    .border(1.dp, item.iconBgColor.copy(alpha = 0.6f), RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = item.brandIcon,
                                    contentDescription = item.brand,
                                    tint = item.iconBgColor,
                                    modifier = Modifier.size(26.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column {
                                Text(
                                    text = item.rewardTitle,
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    GlowingCoinIcon(size = 16.dp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${item.coinRequirement} Coins",
                                        color = CoinNovaGold,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }

                        // Blue Redeem Button (as specified)
                        Button(
                            onClick = { itemToRedeem = item },
                            shape = RoundedCornerShape(22.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CoinNovaBlue
                            ),
                            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "Redeem",
                                color = TextWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Redeem Input Dialog
    itemToRedeem?.let { item ->
        RedeemConfirmationDialog(
            item = item,
            userCoins = currentCoins,
            onDismiss = { itemToRedeem = null },
            onConfirm = { recipientDetails ->
                onRedeem(
                    item.brand,
                    item.rewardTitle,
                    item.coinRequirement,
                    item.cashValue,
                    recipientDetails
                ) { success, msg ->
                    itemToRedeem = null
                    scope.launch {
                        snackbarHostState.showSnackbar(msg)
                    }
                }
            }
        )
    }
}

@Composable
fun RedeemConfirmationDialog(
    item: RedeemItem,
    userCoins: Int,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var recipientInput by remember {
        mutableStateOf(
            if (item.brand == "Free Fire") "UID: 94827103" else "alex.morgan@gmail.com"
        )
    }
    val canAfford = userCoins >= item.coinRequirement

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(CoinNovaSurface)
                .border(1.5.dp, GlassBorderGold, RoundedCornerShape(22.dp))
                .padding(22.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Confirm Redemption",
                        color = TextWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextLightGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Item info preview
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(CoinNovaSurfaceCard)
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = item.brandIcon,
                        contentDescription = null,
                        tint = item.iconBgColor,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = item.rewardTitle,
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Cost: ${item.coinRequirement} Coins • Value: ${item.cashValue}",
                            color = CoinNovaGold,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = if (item.brand == "Free Fire") "Enter Player UID" else "Enter Delivery Email Address",
                    color = TextLightGray,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = recipientInput,
                    onValueChange = { recipientInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedBorderColor = CoinNovaBlue,
                        unfocusedBorderColor = GlassBorder,
                        focusedContainerColor = CoinNovaSurfaceCard,
                        unfocusedContainerColor = CoinNovaSurfaceCard
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (!canAfford) {
                    Text(
                        text = "⚠️ You need ${item.coinRequirement - userCoins} more coins to redeem this reward.",
                        color = Color(0xFFFF6B6B),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Button(
                    onClick = { onConfirm(recipientInput) },
                    enabled = canAfford && recipientInput.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CoinNovaBlue)
                ) {
                    Text(
                        text = "Confirm & Redeem Code",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}
