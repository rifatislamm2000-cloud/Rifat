package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val CoinNovaColorScheme = darkColorScheme(
    primary = CoinNovaBlue,
    onPrimary = TextWhite,
    primaryContainer = CoinNovaSurfaceLight,
    onPrimaryContainer = TextWhite,
    secondary = CoinNovaGold,
    onSecondary = CoinNovaBg,
    secondaryContainer = CoinNovaPurple,
    onSecondaryContainer = TextWhite,
    tertiary = CoinNovaGreen,
    onTertiary = TextWhite,
    background = CoinNovaBg,
    onBackground = TextWhite,
    surface = CoinNovaSurface,
    onSurface = TextWhite,
    surfaceVariant = CoinNovaSurfaceCard,
    onSurfaceVariant = TextLightGray,
    error = CoinNovaRed,
    onError = TextWhite,
    outline = GlassBorder
)

val CoinNovaShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(22.dp), // 22px / dp rounded corners as requested
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun CoinNovaTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CoinNovaColorScheme,
        typography = Typography,
        shapes = CoinNovaShapes,
        content = content
    )
}
