package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.ui.components.CoinNovaBottomNav
import com.example.ui.components.CoinNovaTopBar
import com.example.ui.components.GlassCard
import com.example.ui.components.GlowingCoinIcon
import com.example.ui.theme.CoinNovaBg
import com.example.ui.theme.CoinNovaBlue
import com.example.ui.theme.CoinNovaGold
import com.example.ui.theme.CoinNovaGreen
import com.example.ui.theme.CoinNovaPurple
import com.example.ui.theme.CoinNovaSurface
import com.example.ui.theme.CoinNovaSurfaceCard
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassBorderGold
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

data class LeaderboardUser(
    val rank: Int,
    val username: String,
    val coins: Int,
    val isCurrentUser: Boolean = false
)

@Composable
fun LeaderboardScreen(
    userProfile: UserProfile?,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentUserName = userProfile?.name ?: "Alex Morgan"
    val currentUserCoins = userProfile?.coins ?: 380

    // Top 100 users list with current user highlighted
    val leaderboardUsers = remember(userProfile) {
        val list = mutableListOf(
            LeaderboardUser(1, "CipherNova", 48500),
            LeaderboardUser(2, "GoldenViper", 39200),
            LeaderboardUser(3, "NexusPro", 31450),
            LeaderboardUser(4, "ShadowKnight", 24800),
            LeaderboardUser(5, "CryptoKing", 19500),
            LeaderboardUser(6, "NovaVortex", 15200),
            LeaderboardUser(7, "ZenithEarn", 12300),
            LeaderboardUser(8, "PixelHero", 9800),
            LeaderboardUser(9, "AuraStrike", 8600),
            LeaderboardUser(10, "StormBringer", 7400),
            LeaderboardUser(11, "TitanGamer", 6850),
            LeaderboardUser(12, "QuantumWolf", 5900),
            LeaderboardUser(13, "Valkyrie", 5100),
            LeaderboardUser(14, currentUserName, currentUserCoins, isCurrentUser = true),
            LeaderboardUser(15, "CyberFox", 4600),
            LeaderboardUser(16, "ApexFalcon", 4200),
            LeaderboardUser(17, "Solaris", 3900),
            LeaderboardUser(18, "MysticByte", 3500),
            LeaderboardUser(19, "EchoPulse", 3100),
            LeaderboardUser(20, "BlazeRunner", 2800)
        )
        // Add more users up to top 100
        for (i in 21..100) {
            val dummyCoins = (2800 - (i - 20) * 25).coerceAtLeast(300)
            list.add(LeaderboardUser(i, "Player_Nova$i", dummyCoins))
        }
        list
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CoinNovaBg,
        topBar = {
            CoinNovaTopBar(
                username = userProfile?.name ?: "Alex Morgan",
                coinBalance = userProfile?.coins ?: 0,
                level = userProfile?.level ?: 3,
                onAvatarClick = { onNavigate("profile") },
                onNotificationClick = {},
                onCoinClick = { onNavigate("redeem") }
            )
        },
        bottomBar = {
            Column {
                // Highlighted Current User Pinned Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CoinNovaSurface)
                        .border(1.dp, CoinNovaGold, RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                        .padding(horizontal = 20.dp, vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CoinNovaGold)
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "#14",
                                    color = CoinNovaBg,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = currentUserName,
                                        color = TextWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(CoinNovaBlue)
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = "YOU",
                                            color = TextWhite,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                                Text(
                                    text = "Top 15% Player",
                                    color = TextLightGray,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            GlowingCoinIcon(size = 18.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$currentUserCoins",
                                color = CoinNovaGold,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }

                CoinNovaBottomNav(
                    currentRoute = "leaderboard",
                    onNavigate = onNavigate
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp)
        ) {
            // Top 3 Podium
            item {
                PodiumSection(
                    first = leaderboardUsers[0],
                    second = leaderboardUsers[1],
                    third = leaderboardUsers[2]
                )
            }

            item {
                Text(
                    text = "Top 100 Champions",
                    color = TextWhite,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            // Remaining list items (rank 4 to 100)
            itemsIndexed(leaderboardUsers.drop(3)) { _, user ->
                val isSelf = user.isCurrentUser
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 18.dp,
                    borderColor = if (isSelf) CoinNovaGold else GlassBorder,
                    gradientColors = if (isSelf) {
                        listOf(Color(0xFF22365E), CoinNovaSurface)
                    } else {
                        listOf(CoinNovaSurfaceCard, CoinNovaSurface)
                    }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "#${user.rank}",
                                color = if (isSelf) CoinNovaGold else TextMuted,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                modifier = Modifier.width(36.dp)
                            )

                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isSelf) CoinNovaBlue else CoinNovaSurface
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelf) CoinNovaGold else GlassBorder,
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = TextWhite,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = user.username,
                                        color = TextWhite,
                                        fontWeight = if (isSelf) FontWeight.ExtraBold else FontWeight.SemiBold,
                                        fontSize = 14.sp
                                    )
                                    if (isSelf) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(CoinNovaGold)
                                                .padding(horizontal = 5.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = "YOU",
                                                color = CoinNovaBg,
                                                fontWeight = FontWeight.Black,
                                                fontSize = 9.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            GlowingCoinIcon(size = 16.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${user.coins}",
                                color = CoinNovaGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PodiumSection(
    first: LeaderboardUser,
    second: LeaderboardUser,
    third: LeaderboardUser,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier.fillMaxWidth(),
        cornerRadius = 22.dp,
        borderColor = GlassBorderGold,
        gradientColors = listOf(
            Color(0xFF162544),
            CoinNovaSurface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = CoinNovaGold,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Weekly Top Winners",
                    color = CoinNovaGold,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                // Rank 2 (Silver)
                PodiumUserPillar(
                    user = second,
                    rank = 2,
                    pedestalHeight = 70.dp,
                    color = Color(0xFFBAC7DE),
                    modifier = Modifier.weight(1f)
                )

                // Rank 1 (Gold)
                PodiumUserPillar(
                    user = first,
                    rank = 1,
                    pedestalHeight = 95.dp,
                    color = CoinNovaGold,
                    modifier = Modifier.weight(1f)
                )

                // Rank 3 (Bronze)
                PodiumUserPillar(
                    user = third,
                    rank = 3,
                    pedestalHeight = 55.dp,
                    color = Color(0xFFCD7F32),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun PodiumUserPillar(
    user: LeaderboardUser,
    rank: Int,
    pedestalHeight: androidx.compose.ui.unit.Dp,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.padding(horizontal = 4.dp)
    ) {
        // Crown / Rank badge
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$rank",
                color = CoinNovaBg,
                fontWeight = FontWeight.Black,
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Avatar
        Box(
            modifier = Modifier
                .size(if (rank == 1) 48.dp else 40.dp)
                .clip(CircleShape)
                .background(CoinNovaSurfaceCard)
                .border(2.dp, color, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = null,
                tint = TextWhite,
                modifier = Modifier.size(if (rank == 1) 28.dp else 22.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = user.username,
            color = TextWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            maxLines = 1
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            GlowingCoinIcon(size = 12.dp)
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = "${user.coins}",
                color = CoinNovaGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Pedestal
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(pedestalHeight)
                .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            color.copy(alpha = 0.35f),
                            CoinNovaSurfaceCard
                        )
                    )
                )
                .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "#$rank",
                color = color,
                fontWeight = FontWeight.Black,
                fontSize = 20.sp
            )
        }
    }
}
