package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.PaintingStyle
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CoinBadge
import com.example.ui.components.GlowingCoinIcon
import com.example.ui.components.RewardCelebrationDialog
import com.example.ui.theme.CoinNovaBg
import com.example.ui.theme.CoinNovaBlue
import com.example.ui.theme.CoinNovaGold
import com.example.ui.theme.CoinNovaGoldDark
import com.example.ui.theme.CoinNovaGreen
import com.example.ui.theme.CoinNovaPurple
import com.example.ui.theme.CoinNovaSurface
import com.example.ui.theme.CoinNovaSurfaceCard
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassBorderGold
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

// Rewards: 10, 30, 50, 100, 250, 500, 1000 Coins
val spinRewards = listOf(10, 50, 100, 30, 1000, 50, 250, 500)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LuckySpinScreen(
    currentCoins: Int,
    spinsLeft: Int,
    onBack: () -> Unit,
    onSpinComplete: (Int, (Boolean) -> Unit) -> Unit,
    onViewSpinHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var isSpinning by remember { mutableStateOf(false) }
    var celebrationWonCoins by remember { mutableStateOf<Int?>(null) }

    val wheelRotation = remember { Animatable(0f) }

    fun spinWheel() {
        if (isSpinning) return
        if (spinsLeft <= 0) {
            scope.launch {
                snackbarHostState.showSnackbar("Daily limit reached (10/10). Come back tomorrow!")
            }
            return
        }

        isSpinning = true
        scope.launch {
            // Pick winning segment
            val winningIndex = Random.nextInt(spinRewards.size)
            val wonReward = spinRewards[winningIndex]

            // Calculate target angle
            // 8 segments = 45 degrees per segment
            val segmentAngle = 360f / spinRewards.size
            // Pointer is at top (270 degrees in canvas coords, or top needle)
            // Segment i occupies [i * 45, (i+1) * 45]
            val targetSegmentCenter = (winningIndex * segmentAngle) + (segmentAngle / 2f)
            // For pointer at top (270°), we rotate the wheel so that targetSegmentCenter is at 270°
            val finalTargetAngle = (360f - targetSegmentCenter + 270f) % 360f

            // Realistic multi-revolution physics (6 full spins + offset)
            val fullSpins = 360f * 6
            val currentAngle = wheelRotation.value % 360f
            val destination = wheelRotation.value - currentAngle + fullSpins + finalTargetAngle

            // Smooth realistic deceleration curve
            val realisticEasing = CubicBezierEasing(0.12f, 0.8f, 0.2f, 1.0f)

            wheelRotation.animateTo(
                targetValue = destination,
                animationSpec = tween(durationMillis = 4500, easing = realisticEasing)
            )

            isSpinning = false
            onSpinComplete(wonReward) { success ->
                if (success) {
                    celebrationWonCoins = wonReward
                }
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CoinNovaBg,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Lucky Spin",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, enabled = !isSpinning) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = if (isSpinning) TextMuted else TextWhite
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onViewSpinHistory, enabled = !isSpinning) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Spin History",
                            tint = CoinNovaGold
                        )
                    }
                    CoinBadge(coins = currentCoins, modifier = Modifier.padding(end = 12.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CoinNovaSurface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header stats
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Spin & Win Gold Coins",
                    color = TextWhite,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Jackpot up to 1000 Coins every spin!",
                    color = CoinNovaGold,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Spins Remaining Pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(22.dp))
                        .background(CoinNovaSurface)
                        .border(1.dp, GlassBorderGold, RoundedCornerShape(22.dp))
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Spins Remaining Today: ",
                        color = TextLightGray,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "$spinsLeft / 10",
                        color = if (spinsLeft > 0) CoinNovaGreen else CoinNovaGold,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp
                    )
                }
            }

            // Wheel Container with Needle Pointer
            Box(
                modifier = Modifier
                    .size(310.dp)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                // Outer glowing halo
                Box(
                    modifier = Modifier
                        .size(300.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(CoinNovaPurple.copy(alpha = 0.35f), Color.Transparent)
                            )
                        )
                )

                // Spinning Wheel Canvas
                Canvas(
                    modifier = Modifier
                        .size(280.dp)
                        .rotate(wheelRotation.value)
                ) {
                    drawLuckyWheel(spinRewards)
                }

                // Center Nova Hub
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(CoinNovaGold, CoinNovaGoldDark)
                            )
                        )
                        .border(2.5.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    GlowingCoinIcon(size = 28.dp)
                }

                // Top Pointer Needle
                Canvas(
                    modifier = Modifier
                        .size(36.dp)
                        .align(Alignment.TopCenter)
                        .offset(y = (-6).dp)
                ) {
                    val path = Path().apply {
                        moveTo(size.width / 2f, size.height) // pointing down into wheel
                        lineTo(size.width * 0.15f, 0f)
                        lineTo(size.width * 0.85f, 0f)
                        close()
                    }
                    drawPath(
                        path = path,
                        brush = Brush.verticalGradient(listOf(Color.White, CoinNovaGold))
                    )
                    drawPath(
                        path = path,
                        color = Color(0xFF5A3E00),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }

            // Spin Action Button
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = { spinWheel() },
                    enabled = !isSpinning && spinsLeft > 0,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CoinNovaBlue,
                        disabledContainerColor = CoinNovaSurface
                    )
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RotateRight,
                            contentDescription = null,
                            tint = if (spinsLeft > 0 && !isSpinning) TextWhite else TextMuted,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpinning) "Spinning Wheel..." else if (spinsLeft > 0) "SPIN THE WHEEL" else "Daily Limit Reached",
                            color = if (spinsLeft > 0 && !isSpinning) TextWhite else TextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Daily limit resets every 24 hours.",
                    color = TextMuted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    // Celebration Dialog on Win
    celebrationWonCoins?.let { won ->
        RewardCelebrationDialog(
            coinsWon = won,
            title = if (won >= 500) "JACKPOT!" else "Lucky Spin Win!",
            subtitle = "The wheel stopped on",
            onDismiss = { celebrationWonCoins = null }
        )
    }
}

private fun DrawScope.drawLuckyWheel(rewards: List<Int>) {
    val radius = size.minDimension / 2f
    val center = Offset(radius, radius)
    val numSegments = rewards.size
    val sweepAngle = 360f / numSegments

    val segmentColors = listOf(
        Color(0xFF0F2652),
        Color(0xFF7A3CFF),
        Color(0xFF1B3B73),
        Color(0xFF5B22BF),
        Color(0xFF0B1E40),
        Color(0xFF904BFF),
        Color(0xFF163260),
        Color(0xFF38147E)
    )

    // Outer gold border ring
    drawCircle(
        brush = Brush.radialGradient(
            listOf(CoinNovaGold, CoinNovaGoldDark),
            center = center,
            radius = radius
        ),
        radius = radius
    )

    // Inner wheel segments
    val innerRadius = radius - 8.dp.toPx()
    for (i in 0 until numSegments) {
        val startAngle = i * sweepAngle
        val color = segmentColors[i % segmentColors.size]

        drawArc(
            color = color,
            startAngle = startAngle,
            sweepAngle = sweepAngle,
            useCenter = true,
            size = Size(innerRadius * 2f, innerRadius * 2f),
            topLeft = Offset(center.x - innerRadius, center.y - innerRadius)
        )

        // Arc divider lines
        val rad = Math.toRadians(startAngle.toDouble())
        val endX = (center.x + innerRadius * cos(rad)).toFloat()
        val endY = (center.y + innerRadius * sin(rad)).toFloat()
        drawLine(
            color = CoinNovaGold.copy(alpha = 0.8f),
            start = center,
            end = Offset(endX, endY),
            strokeWidth = 2.dp.toPx()
        )

        // Draw reward text inside segment using native canvas
        val midAngle = startAngle + (sweepAngle / 2f)
        val textRad = Math.toRadians(midAngle.toDouble())
        val textDist = innerRadius * 0.65f
        val tx = (center.x + textDist * cos(textRad)).toFloat()
        val ty = (center.y + textDist * sin(textRad)).toFloat()

        drawIntoCanvas { canvas ->
            val native = canvas.nativeCanvas
            native.save()
            native.translate(tx, ty)
            native.rotate(midAngle + 90f)

            val paint = android.graphics.Paint().apply {
                this.color = if (rewards[i] >= 500) CoinNovaGold.toArgb() else android.graphics.Color.WHITE
                textSize = if (rewards[i] >= 1000) 34f else 36f
                isFakeBoldText = true
                textAlign = android.graphics.Paint.Align.CENTER
                setShadowLayer(4f, 0f, 2f, android.graphics.Color.BLACK)
            }
            native.drawText("${rewards[i]}", 0f, 0f, paint)
            native.restore()
        }
    }

    // Outer glowing light bulbs
    val numBulbs = 16
    for (b in 0 until numBulbs) {
        val bAngle = b * (360f / numBulbs)
        val bRad = Math.toRadians(bAngle.toDouble())
        val bDist = radius - 4.dp.toPx()
        val bx = (center.x + bDist * cos(bRad)).toFloat()
        val by = (center.y + bDist * sin(bRad)).toFloat()
        drawCircle(
            color = if (b % 2 == 0) Color.White else CoinNovaGold,
            radius = 3.dp.toPx(),
            center = Offset(bx, by)
        )
    }
}
