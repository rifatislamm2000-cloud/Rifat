package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CoinBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.GlowingCoinIcon
import com.example.ui.components.RewardCelebrationDialog
import com.example.ui.theme.CoinNovaBg
import com.example.ui.theme.CoinNovaBlue
import com.example.ui.theme.CoinNovaGold
import com.example.ui.theme.CoinNovaGreen
import com.example.ui.theme.CoinNovaPurple
import com.example.ui.theme.CoinNovaRed
import com.example.ui.theme.CoinNovaSurface
import com.example.ui.theme.CoinNovaSurfaceCard
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassBorderGold
import com.example.ui.theme.GlassBorderPurple
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

data class QuizItem(
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val category: String
)

private val quizPool = listOf(
    QuizItem(
        question = "What is the consensus algorithm used by Bitcoin?",
        options = listOf("Proof of Stake", "Proof of Work", "Proof of History", "Proof of Authority"),
        correctIndex = 1,
        category = "Crypto & Tech"
    ),
    QuizItem(
        question = "Which planet in our solar system is known as the Red Planet?",
        options = listOf("Venus", "Jupiter", "Mars", "Saturn"),
        correctIndex = 2,
        category = "Science"
    ),
    QuizItem(
        question = "In gaming, what does the term 'FPS' stand for?",
        options = listOf("Frames Per Second", "First Person Skill", "Fast Point System", "Final Player Strike"),
        correctIndex = 0,
        category = "Gaming"
    ),
    QuizItem(
        question = "What year was the Android operating system publicly released?",
        options = listOf("2005", "2008", "2010", "2012"),
        correctIndex = 1,
        category = "Technology"
    ),
    QuizItem(
        question = "Which virtual currency is used in Free Fire for rewards?",
        options = listOf("Gems", "Gold Bars", "Diamonds", "Nova Points"),
        correctIndex = 2,
        category = "Gaming"
    ),
    QuizItem(
        question = "Which programming language is officially recommended for modern Android development?",
        options = listOf("Java", "Kotlin", "Swift", "C++"),
        correctIndex = 1,
        category = "Technology"
    ),
    QuizItem(
        question = "What is the highest reward possible on the CoinNova Lucky Spin wheel?",
        options = listOf("250 Coins", "500 Coins", "1000 Coins", "2000 Coins"),
        correctIndex = 2,
        category = "CoinNova"
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(
    currentCoins: Int,
    onBack: () -> Unit,
    onCorrectAnswer: (() -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var currentIndex by remember { mutableIntStateOf(0) }
    var selectedOption by remember { mutableStateOf<Int?>(null) }
    var isAnswerSubmitted by remember { mutableStateOf(false) }
    var isAnswerCorrect by remember { mutableStateOf(false) }
    var celebrationCoinsWon by remember { mutableStateOf<Int?>(null) }

    val shakeOffset = remember { Animatable(0f) }

    val currentQuestion = quizPool[currentIndex % quizPool.size]

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CoinNovaBg,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Trivia Quiz",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextWhite
                        )
                    }
                },
                actions = {
                    CoinBadge(coins = currentCoins, modifier = Modifier.padding(end = 12.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CoinNovaSurface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Status: Question number & Category
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(CoinNovaPurple.copy(alpha = 0.3f))
                            .border(1.dp, CoinNovaPurple, RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = currentQuestion.category,
                            color = CoinNovaGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "Question ${currentIndex + 1} of ${quizPool.size}",
                        color = TextMuted,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Question Box
                Box(
                    modifier = Modifier
                        .offset { IntOffset(x = shakeOffset.value.roundToInt(), y = 0) }
                        .fillMaxWidth()
                ) {
                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        borderColor = if (isAnswerSubmitted && !isAnswerCorrect) CoinNovaRed else GlassBorderPurple,
                        gradientColors = listOf(
                            CoinNovaSurfaceCard,
                            CoinNovaSurface
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(22.dp)
                        ) {
                            Text(
                                text = currentQuestion.question,
                                color = TextWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 24.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                GlowingCoinIcon(size = 18.dp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Correct answer: +10 Coins",
                                    color = CoinNovaGold,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // 4 Answer Options
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    currentQuestion.options.forEachIndexed { index, optionText ->
                        val isSelected = selectedOption == index
                        val isCorrect = currentQuestion.correctIndex == index

                        val cardBorderColor by animateColorAsState(
                            targetValue = when {
                                !isAnswerSubmitted -> if (isSelected) CoinNovaBlue else GlassBorder
                                isCorrect -> CoinNovaGreen
                                isSelected -> CoinNovaRed
                                else -> GlassBorder.copy(alpha = 0.3f)
                            },
                            label = "border_color"
                        )

                        val cardBgColor by animateColorAsState(
                            targetValue = when {
                                !isAnswerSubmitted -> if (isSelected) CoinNovaBlue.copy(alpha = 0.2f) else CoinNovaSurface
                                isCorrect -> CoinNovaGreen.copy(alpha = 0.2f)
                                isSelected -> CoinNovaRed.copy(alpha = 0.25f)
                                else -> CoinNovaSurface.copy(alpha = 0.6f)
                            },
                            label = "bg_color"
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(22.dp))
                                .background(cardBgColor)
                                .border(1.5.dp, cardBorderColor, RoundedCornerShape(22.dp))
                                .clickable(enabled = !isAnswerSubmitted) {
                                    selectedOption = index
                                    isAnswerSubmitted = true
                                    val correct = (index == currentQuestion.correctIndex)
                                    isAnswerCorrect = correct

                                    if (correct) {
                                        onCorrectAnswer {
                                            celebrationCoinsWon = 10
                                        }
                                    } else {
                                        // Trigger red shake animation
                                        scope.launch {
                                            for (i in 0..2) {
                                                shakeOffset.animateTo(20f, tween(50))
                                                shakeOffset.animateTo(-20f, tween(50))
                                            }
                                            shakeOffset.animateTo(0f, tween(50))
                                        }
                                    }
                                }
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when {
                                                isAnswerSubmitted && isCorrect -> CoinNovaGreen
                                                isAnswerSubmitted && isSelected -> CoinNovaRed
                                                isSelected -> CoinNovaBlue
                                                else -> CoinNovaSurfaceCard
                                            }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    val letter = ('A' + index).toString()
                                    Text(
                                        text = letter,
                                        color = TextWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Text(
                                    text = optionText,
                                    color = TextWhite,
                                    fontSize = 15.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }

                            if (isAnswerSubmitted) {
                                if (isCorrect) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Correct",
                                        tint = CoinNovaGreen,
                                        modifier = Modifier.size(22.dp)
                                    )
                                } else if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Wrong",
                                        tint = CoinNovaRed,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Bottom action: Next question
            if (isAnswerSubmitted) {
                Button(
                    onClick = {
                        isAnswerSubmitted = false
                        selectedOption = null
                        currentIndex = (currentIndex + 1) % quizPool.size
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CoinNovaBlue
                    )
                ) {
                    Text(
                        text = if (currentIndex < quizPool.size - 1) "Next Question →" else "Start Over",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            } else {
                Text(
                    text = "Select an option to submit your answer instantly.",
                    color = TextMuted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    // Correct celebration popup
    celebrationCoinsWon?.let { coins ->
        RewardCelebrationDialog(
            coinsWon = coins,
            title = "Correct Answer!",
            subtitle = "You nailed the quiz",
            onDismiss = { celebrationCoinsWon = null }
        )
    }
}
