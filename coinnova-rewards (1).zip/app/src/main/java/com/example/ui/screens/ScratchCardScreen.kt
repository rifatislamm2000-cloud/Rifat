package com.example.ui.screens

import android.app.Activity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ads.AdManager
import com.example.ui.components.CoinBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.GlowingCoinIcon
import com.example.ui.components.RewardCelebrationDialog
import com.example.ui.theme.CoinNovaBg
import com.example.ui.theme.CoinNovaBlue
import com.example.ui.theme.CoinNovaGold
import com.example.ui.theme.CoinNovaGreen
import com.example.ui.theme.CoinNovaPurple
import com.example.ui.theme.CoinNovaSurface
import com.example.ui.theme.CoinNovaSurfaceCard
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassBorderGold
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScratchCardScreen(
    currentCoins: Int,
    onBack: () -> Unit,
    onClaimCoins: (Int, () -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity

    var rewardCoins by remember { mutableIntStateOf(Random.nextInt(2, 6)) } // Range: 2–5 Coins
    val scratchPoints = remember { mutableStateListOf<Offset>() }
    var isRevealed by remember { mutableStateOf(false) }
    var isWatchingClaimAd by remember { mutableStateOf(false) }
    var showCelebrationDialog by remember { mutableStateOf(false) }

    fun resetCard() {
        rewardCoins = Random.nextInt(2, 6)
        scratchPoints.clear()
        isRevealed = false
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CoinNovaBg,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Scratch & Win",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextWhite
                        )
                    }
                },
                actions = {
                    CoinBadge(coins = currentCoins, modifier = Modifier.padding(end = 12.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CoinNovaSurface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header stats
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Unlimited Scratch Cards",
                    color = TextWhite,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Scratch with your finger to reveal 2–5 Coins!",
                    color = CoinNovaGold,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Scratch Card Area
            Box(
                modifier = Modifier
                    .size(width = 280.dp, height = 280.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(CoinNovaSurface)
                    .border(2.dp, GlassBorderGold, RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Underneath Reward Layer
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0xFF1B3C73),
                                    CoinNovaSurfaceCard
                                )
                            )
                        )
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    GlowingCoinIcon(size = 76.dp)
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "+$rewardCoins Coins",
                        color = CoinNovaGold,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "YOU WON!",
                        color = TextWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                }

                // Scratchable Top Foil Layer (using BlendMode.Clear with layer)
                if (!isRevealed) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { alpha = 0.99f }
                            .pointerInput(Unit) {
                                detectDragGestures { change, _ ->
                                    change.consume()
                                    scratchPoints.add(change.position)
                                    // Once user has scratched enough (e.g. 35+ scratch points)
                                    if (scratchPoints.size > 35) {
                                        isRevealed = true
                                    }
                                }
                            }
                    ) {
                        // Draw Foil Background
                        drawRect(
                            brush = Brush.linearGradient(
                                listOf(
                                    Color(0xFF3A4D6E),
                                    Color(0xFF1E2F4D),
                                    Color(0xFF4C648E)
                                )
                            )
                        )

                        // Foil pattern icon
                        val patternColor = Color.White.copy(alpha = 0.15f)
                        for (x in 30..size.width.toInt() step 60) {
                            for (y in 30..size.height.toInt() step 60) {
                                drawCircle(
                                    color = patternColor,
                                    radius = 4.dp.toPx(),
                                    center = Offset(x.toFloat(), y.toFloat())
                                )
                            }
                        }

                        // Scratch erasing path
                        if (scratchPoints.isNotEmpty()) {
                            val path = Path()
                            scratchPoints.forEachIndexed { index, point ->
                                if (index == 0) path.moveTo(point.x, point.y)
                                else path.lineTo(point.x, point.y)
                            }
                            drawPath(
                                path = path,
                                color = Color.Transparent,
                                style = Stroke(
                                    width = 65.dp.toPx(),
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round
                                ),
                                blendMode = BlendMode.Clear
                            )
                        }
                    }

                    // Prompt overlay while not scratched
                    if (scratchPoints.isEmpty()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(22.dp))
                                .background(CoinNovaBg.copy(alpha = 0.7f))
                                .border(1.dp, CoinNovaGold.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = CoinNovaGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Scratch Foil with Finger",
                                color = TextWhite,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // Bottom Actions: Claim Reward Button (triggers Rewarded Ad)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isRevealed) {
                    Button(
                        onClick = {
                            if (activity != null) {
                                AdManager.showRewardedAd(
                                    activity = activity,
                                    onRewardEarned = {
                                        onClaimCoins(rewardCoins) {
                                            showCelebrationDialog = true
                                        }
                                    },
                                    onAdClosed = {},
                                    onFallbackSimulation = {
                                        // Quick rewarded ad simulation
                                        onClaimCoins(rewardCoins) {
                                            showCelebrationDialog = true
                                        }
                                    }
                                )
                            } else {
                                onClaimCoins(rewardCoins) {
                                    showCelebrationDialog = true
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CoinNovaGreen
                        )
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.OndemandVideo,
                                contentDescription = null,
                                tint = TextWhite,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Claim +$rewardCoins Coins (Watch Ad)",
                                color = TextWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { resetCard() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CoinNovaSurface
                        )
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                tint = CoinNovaGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Scratch Another Card",
                                color = CoinNovaGold,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                        }
                    }
                } else {
                    Text(
                        text = "Scratch the card to uncover your hidden coins.",
                        color = TextMuted,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }

    // Celebration Dialog when claimed
    if (showCelebrationDialog) {
        RewardCelebrationDialog(
            coinsWon = rewardCoins,
            title = "Reward Claimed!",
            subtitle = "You earned from Scratch Card",
            onDismiss = {
                showCelebrationDialog = false
                resetCard()
            }
        )
    }
}
