package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.CoinNovaBg
import com.example.ui.theme.CoinNovaBlue
import com.example.ui.theme.CoinNovaGold
import com.example.ui.theme.CoinNovaGoldDark
import com.example.ui.theme.CoinNovaGreen
import com.example.ui.theme.CoinNovaPurple
import com.example.ui.theme.CoinNovaRed
import com.example.ui.theme.CoinNovaSurface
import com.example.ui.theme.CoinNovaSurfaceCard
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.TextLightGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlin.math.cos
import kotlin.math.sin

/**
 * Glassmorphic luxury card with 22px rounded corners and subtle glowing border
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 22.dp,
    borderColor: Color = GlassBorder,
    borderWidth: Dp = 1.dp,
    gradientColors: List<Color> = listOf(
        CoinNovaSurfaceCard.copy(alpha = 0.85f),
        CoinNovaSurface.copy(alpha = 0.95f)
    ),
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val cardModifier = if (onClick != null) {
        modifier
            .clip(shape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
    } else {
        modifier.clip(shape)
    }

    Box(
        modifier = cardModifier
            .background(
                Brush.linearGradient(
                    colors = gradientColors,
                    start = Offset(0f, 0f),
                    end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                )
            )
            .border(
                borderWidth,
                Brush.linearGradient(
                    listOf(
                        borderColor,
                        CoinNovaPurple.copy(alpha = 0.2f),
                        borderColor.copy(alpha = 0.4f)
                    )
                ),
                shape
            )
    ) {
        content()
    }
}

/**
 * Luxury glowing Coin Balance Badge
 */
@Composable
fun CoinBadge(
    coins: Int,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        CoinNovaSurface,
                        Color(0xFF1B2F57)
                    )
                )
            )
            .border(
                1.dp,
                Brush.horizontalGradient(listOf(CoinNovaGold.copy(alpha = 0.8f), CoinNovaPurple.copy(alpha = 0.4f))),
                shape
            )
            .clickable(enabled = onClick != null) { onClick?.invoke() }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GlowingCoinIcon(size = 20.dp)
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = "$coins",
            color = CoinNovaGold,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            letterSpacing = 0.5.sp
        )
    }
}

/**
 * Procedural Vector Gold Coin with Nova Star emblem
 */
@Composable
fun GlowingCoinIcon(
    modifier: Modifier = Modifier,
    size: Dp = 24.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val radius = this.size.minDimension / 2f
        val center = Offset(radius, radius)

        // Outer Glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(CoinNovaGold.copy(alpha = 0.4f), Color.Transparent),
                center = center,
                radius = radius * 1.3f
            ),
            radius = radius * 1.3f
        )

        // Outer Ring
        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(CoinNovaGold, CoinNovaGoldDark),
                start = Offset.Zero,
                end = Offset(this.size.width, this.size.height)
            ),
            radius = radius
        )

        // Inner Inset
        drawCircle(
            color = Color(0xFFC9860A),
            radius = radius * 0.85f,
            style = Stroke(width = radius * 0.08f)
        )

        // Nova Star in center
        val starPath = Path()
        val numPoints = 4
        val outerR = radius * 0.55f
        val innerR = radius * 0.22f
        for (i in 0 until numPoints * 2) {
            val r = if (i % 2 == 0) outerR else innerR
            val angle = (i * Math.PI / numPoints) - Math.PI / 2
            val x = (center.x + r * cos(angle)).toFloat()
            val y = (center.y + r * sin(angle)).toFloat()
            if (i == 0) starPath.moveTo(x, y) else starPath.lineTo(x, y)
        }
        starPath.close()

        drawPath(
            path = starPath,
            brush = Brush.linearGradient(
                colors = listOf(Color.White, CoinNovaGold),
                start = Offset(center.x, center.y - outerR),
                end = Offset(center.x, center.y + outerR)
            )
        )
    }
}

/**
 * Top Bar with Profile avatar, Username, Coin Balance, and Notification Bell
 */
@Composable
fun CoinNovaTopBar(
    username: String,
    coinBalance: Int,
    level: Int,
    onAvatarClick: () -> Unit,
    onNotificationClick: () -> Unit,
    onCoinClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar + User Info
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(22.dp))
                .clickable { onAvatarClick() }
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(listOf(CoinNovaBlue, CoinNovaPurple))
                    )
                    .border(1.5.dp, CoinNovaGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "User Avatar",
                    tint = TextWhite,
                    modifier = Modifier.size(26.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = username,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(CoinNovaPurple.copy(alpha = 0.4f))
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "LVL $level",
                            color = CoinNovaGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "VIP Player",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Coins + Notification
        Row(verticalAlignment = Alignment.CenterVertically) {
            CoinBadge(coins = coinBalance, onClick = onCoinClick)
            Spacer(modifier = Modifier.width(10.dp))
            IconButton(
                onClick = onNotificationClick,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(CoinNovaSurface)
                    .border(1.dp, GlassBorder, CircleShape)
            ) {
                BadgedBox(
                    badge = {
                        Badge(
                            containerColor = CoinNovaRed,
                            modifier = Modifier.size(8.dp)
                        )
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications",
                        tint = TextLightGray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

/**
 * Multi-color Google "G" icon
 */
@Composable
fun GoogleLogoIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(24.dp)) {
        val sizePx = size.minDimension
        val strokeW = sizePx * 0.18f

        // Google Red (Top-left arc)
        drawArc(
            color = Color(0xFFEA4335),
            startAngle = 180f,
            sweepAngle = 105f,
            useCenter = false,
            style = Stroke(width = strokeW, cap = StrokeCap.Butt)
        )
        // Google Yellow (Bottom-left arc)
        drawArc(
            color = Color(0xFFFBBC05),
            startAngle = 135f,
            sweepAngle = 45f,
            useCenter = false,
            style = Stroke(width = strokeW, cap = StrokeCap.Butt)
        )
        // Google Green (Bottom-right arc)
        drawArc(
            color = Color(0xFF34A853),
            startAngle = 45f,
            sweepAngle = 90f,
            useCenter = false,
            style = Stroke(width = strokeW, cap = StrokeCap.Butt)
        )
        // Google Blue (Top right & Horizontal Bar)
        drawArc(
            color = Color(0xFF4285F4),
            startAngle = 315f,
            sweepAngle = 90f,
            useCenter = false,
            style = Stroke(width = strokeW, cap = StrokeCap.Butt)
        )
        // Horizontal bar
        drawLine(
            color = Color(0xFF4285F4),
            start = Offset(sizePx * 0.48f, sizePx * 0.5f),
            end = Offset(sizePx * 0.95f, sizePx * 0.5f),
            strokeWidth = strokeW,
            cap = StrokeCap.Square
        )
    }
}

/**
 * Floating decorative gold coins for Splash and Home
 */
@Composable
fun FloatingCoinsEffect(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "coins_float")
    val floatY1 by infiniteTransition.animateFloat(
        initialValue = -15f,
        targetValue = 15f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "float1"
    )
    val floatY2 by infiniteTransition.animateFloat(
        initialValue = 12f,
        targetValue = -12f,
        animationSpec = infiniteRepeatable(
            animation = tween(3100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "float2"
    )

    Box(modifier = modifier.fillMaxSize()) {
        GlowingCoinIcon(
            size = 36.dp,
            modifier = Modifier
                .align(Alignment.TopStart)
                .offset(x = 28.dp, y = 80.dp + floatY1.dp)
        )
        GlowingCoinIcon(
            size = 28.dp,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = (-32).dp, y = 140.dp + floatY2.dp)
        )
        GlowingCoinIcon(
            size = 42.dp,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(x = 16.dp, y = (-20).dp + floatY2.dp)
        )
        GlowingCoinIcon(
            size = 32.dp,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .offset(x = (-40).dp, y = (-120).dp + floatY1.dp)
        )
        GlowingCoinIcon(
            size = 24.dp,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .offset(x = 36.dp, y = (-80).dp + floatY2.dp)
        )
    }
}

/**
 * Bottom Navigation with Home, Refer, Leaderboard, Profile
 */
@Composable
fun CoinNovaBottomNav(
    currentRoute: String,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .background(CoinNovaSurface)
            .border(1.dp, GlassBorder, RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
            .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)),
        containerColor = CoinNovaSurface,
        tonalElevation = 8.dp
    ) {
        val items = listOf(
            Triple("home", "Home", Icons.Default.Home),
            Triple("refer", "Refer", Icons.Default.Share),
            Triple("leaderboard", "Leaderboard", Icons.Default.Leaderboard),
            Triple("profile", "Profile", Icons.Default.AccountCircle)
        )

        items.forEach { (route, label, icon) ->
            val selected = currentRoute == route
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(route) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (selected) CoinNovaGold else TextLightGray
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        color = if (selected) CoinNovaGold else TextMuted
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = CoinNovaBlue.copy(alpha = 0.25f)
                )
            )
        }
    }
}
